let currentIndex = 0;

function moveSlide(direction) {
    const track = document.querySelector('.carousel-track');
    const packages = document.querySelectorAll('.package');
    const totalPackages = packages.length;

    currentIndex = (currentIndex + direction + totalPackages) % totalPackages;
    const offset = -currentIndex * (packages[0].clientWidth + 20
    ); // 20 for margin-right
    track.style.transform = `translateX(${offset}px)`;
}
